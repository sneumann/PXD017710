#PXD107710

## Original Data:

### Provenance Information
- original data:
[10.21203/rs.3.rs-17218/v1](10.21203/rs.3.rs-17218/v1)


- Table S3 | Results of Reactome pathway analysis of genes decreased in protein level during infection (Fig. 3a, S3). Pathway names, size of pathway, proteins found in dataset, P values and FDR are given.
[Supplementary Table 03.xlsx]

- Table S4 | Results of Reactome pathway analysis of genes increased in protein level during infection (Fig. 3a, b). Pathway names, size of pathway, proteins found in dataset, P values and FDR are given.
[Supplementary Table 04.xlsx]

- Table S5 |Results of gene ontology (biological process) analysis of genes following viral gene expression (Fig. 4). GO term, proteins found in dataset, GO size, P value and FDR are given.
Supplementary Table 05.xlsx


## Pathway analysis

### Provenance Information
Table S3 and Table S4 were merged into:
[PXD017710-Results_Reactome_Pathway_analysis_of_protein level_during_SARSCov2_infection.csv]()

### Curation actions:
1. Reformatting to Frictional Template
2. Reactome pathway data was used by the primary authors. However, Reactome pathways or reaction IDs are not used. GO names are used instead. no further actions.


## GO Category enrichment analysis

### Provenance Information
Supplementary Table 05.xlsx (Table S5) was converted into:
[PXD017710-GO-category-enrichment-analysis.csv]()

### Curation actions:
1. Reformatting to Frictional Template
2. Fetching with GO identifiers (query over GO Version: 2020-02-21)

caveats: 
	-gene names are used instead of gene identifiers
	-statistical test not clearly documented
	-overall ambiguity on the filtering and processing.





